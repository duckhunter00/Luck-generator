"use client";
import React from "react";



export default function Index() {
  return (function MainComponent({ children, onClick }) {
  return (
    <button
      className="bg-[#F5663B] text-[#EAEADF] font-montserrat font-semibold tracking-tighter rounded-lg px-4 py-2 transition-colors duration-200 hover:bg-[#DD5C35]"
      onClick={onClick}
    >
      {children}
    </button>
  );
}

function StoryComponent() {
  return (
    <div className="p-4">
      <MainComponent onClick={() => console.log('Button clicked')}>
        Click Me
      </MainComponent>
    </div>
  );
});
}