"use client";
import React from "react";

import { useUpload } from "../utilities/runtime-helpers";

function MainComponent() {
  const [photos, setPhotos] = useState([]);
  const [uploading, setUploading] = useState(false);
  const [file, setFile] = useState(null);
  const [uploadError, setUploadError] = useState(null);
  const { data: user, loading } = useUser();
  const { upload } = useUpload();

  useEffect(() => {
    const fetchPhotos = async () => {
      try {
        const response = await fetch("/api/photos");
        if (!response.ok) {
          throw new Error(
            `When fetching /api/photos, the response was [${response.status}] ${response.statusText}`
          );
        }
        const data = await response.json();
        setPhotos(data);
      } catch (error) {
        console.error("Error fetching photos:", error);
      }
    };
    fetchPhotos();
  }, []);

  const handleUpload = useCallback(async () => {
    if (!user) {
      setUploadError("Please sign in to upload photos");
      return;
    }

    try {
      setUploading(true);
      setUploadError(null);

      if (!file) {
        throw new Error("No file selected.");
      }
      const { url, error } = await upload({ file });

      if (error) {
        throw error;
      }

      const response = await fetch("/api/photos", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ url }),
      });
      if (!response.ok) {
        throw new Error(
          `When uploading a photo, the response was [${response.status}] ${response.statusText}`
        );
      }

      setPhotos([...photos, { url }]);
      setFile(null);
    } catch (error) {
      console.error("Error uploading photo:", error);
      setUploadError("Could not upload photo. Please try again later.");
    } finally {
      setUploading(false);
    }
  }, [file, photos, upload, user]);

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0a0a2a] to-[#1a1a4a] text-white font-poppins">
      <header className="py-6 px-4 md:px-12 flex justify-between items-center">
        <div className="flex items-center space-x-4">
          <h1 className="text-2xl font-bold">Quantum Community</h1>
        </div>
        <div>
          {!loading && !user && (
            <a
              href="/account/signin?callbackUrl=/community"
              className="bg-[#8a6eff] hover:bg-[#7a5eff] text-white font-bold py-2 px-4 rounded-full"
            >
              Sign In
            </a>
          )}
        </div>
      </header>

      <main className="py-12 px-4 md:px-12 max-w-6xl mx-auto">
        <div className="text-center mb-8">
          {loading ? (
            <div className="animate-pulse">Loading...</div>
          ) : user ? (
            <div className="mb-4">
              <label
                htmlFor="upload"
                className="bg-[#8a6eff] hover:bg-[#7a5eff] text-white font-bold py-3 px-6 rounded-full cursor-pointer"
              >
                {uploading ? "Uploading..." : "Upload Photo"}
                <input
                  id="upload"
                  type="file"
                  accept="image/*"
                  onChange={(e) => setFile(e.target.files[0])}
                  className="hidden"
                  disabled={uploading}
                />
              </label>
              {uploadError && (
                <p className="text-red-500 mt-2">{uploadError}</p>
              )}
            </div>
          ) : (
            <div className="bg-[#2a1b6a] rounded-xl p-8 mb-8">
              <h2 className="text-2xl font-bold mb-4">
                Join the Quantum Community!
              </h2>
              <p className="mb-6">
                Sign in to share your quantum-influenced photos and connect with
                fellow enthusiasts.
              </p>
              <a
                href="/account/signin?callbackUrl=/community"
                className="bg-[#8a6eff] hover:bg-[#7a5eff] text-white font-bold py-3 px-6 rounded-full"
              >
                Sign In to Upload
              </a>
            </div>
          )}
          <p className="text-sm text-gray-400">
            Photos are subject to moderation and must adhere to community
            guidelines.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {photos.map((photo, index) => (
            <img
              key={index}
              src={photo.url}
              alt={`User uploaded photo ${index + 1}`}
              className="rounded-lg w-full h-auto object-cover"
            />
          ))}
        </div>
      </main>
    </div>
  );
}

export default MainComponent;