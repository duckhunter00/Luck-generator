"use client";
import React from "react";

import { useUpload } from "../utilities/runtime-helpers";

function MainComponent() {
  const { data: user } = useUser();
  const [posts, setPosts] = useState([]);
  const [newPostType, setNewPostType] = useState("text");
  const [newPostContent, setNewPostContent] = useState("");
  const [newPostFile, setNewPostFile] = useState(null);
  const [upload, { loading: uploading }] = useUpload();
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchPosts = async () => {
      try {
        const response = await fetch("/api/posts");
        if (!response.ok) {
          throw new Error(
            `When fetching posts, the response was [${response.status}] ${response.statusText}`
          );
        }
        const data = await response.json();
        setPosts(data);
      } catch (error) {
        console.error("Error fetching posts:", error);
        setError("Could not fetch posts");
      }
    };

    fetchPosts();
  }, []);

  const handleNewPostChange = (e) => {
    setNewPostContent(e.target.value);
  };

  const handleNewPostFileChange = (e) => {
    if (e.target.files) {
      setNewPostFile(e.target.files[0]);
    }
  };

  const handleSubmitNewPost = useCallback(async () => {
    let uploadedUrl = null;
    if (newPostFile) {
      try {
        const { url, error: uploadError } = await upload({ file: newPostFile });
        if (uploadError) {
          throw uploadError;
        }
        uploadedUrl = url;
      } catch (error) {
        console.error("Error uploading file:", error);
        setError("Failed to upload file. Please try again later.");
        return;
      }
    }

    try {
      const response = await fetch("/api/posts", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          content: newPostContent,
          type: newPostType,
          fileUrl: uploadedUrl,
        }),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      setNewPostContent("");
      setNewPostFile(null);
      setNewPostType("text");

      const newPost = await response.json();
      setPosts([...posts, newPost]);
    } catch (error) {
      console.error("Error creating post:", error);
      setError("Failed to create post. Please try again later.");
    }
  }, [newPostType, newPostContent, newPostFile, upload, posts]);

  const previewForPost = (post) => {
    if (post.type === "image" || post.type === "video") {
      const isImage = post.type === "image";
      const previewUrl = post.fileUrl;

      return (
        <img
          src={previewUrl}
          alt={
            isImage ? "Preview image of user post." : "Preview video thumbnail."
          }
          className="w-full h-auto object-cover rounded-lg"
          style={{ filter: user ? "none" : "blur(8px)" }}
        />
      );
    } else if (post.type === "text") {
      const firstLine = post.content.split("\n")[0];

      return (
        <p
          className="text-lg font-medium text-gray-800"
          style={{ filter: user ? "none" : "blur(2px)" }}
        >
          {firstLine}
        </p>
      );
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0a0a2a] to-[#1a1a4a] text-white font-poppins">
      <header className="py-6 px-4 md:px-12 flex justify-between items-center">
        <div className="flex items-center">
          <div className="w-[50px] h-[50px] rounded-full bg-[#5d3fd3] flex items-center justify-center">
            <i className="fas fa-atom text-2xl"></i>
          </div>
          <h1 className="ml-3 text-2xl md:text-3xl font-bold">
            Quantum Community
          </h1>
        </div>
      </header>

      <main className="py-12 px-4 md:px-12 max-w-6xl mx-auto">
        {!user && (
          <section className="bg-[#2a1b6a] rounded-xl p-8 mb-8 text-center">
            <h2 className="text-3xl font-bold mb-4">
              Join the Quantum Community!
            </h2>
            <p className="text-lg mb-6">
              Unlock full access to discussions, share your experiences, and
              connect with fellow quantum enthusiasts.
            </p>
            <a
              href="/account/signup"
              className="bg-[#8a6eff] hover:bg-[#7a5eff] text-white font-bold py-3 px-6 rounded-full"
            >
              Sign Up Now
            </a>
          </section>
        )}
        {error && <div className="text-red-500 text-center mb-4">{error}</div>}
        {user && (
          <section className="mb-8">
            <h2 className="text-2xl font-bold mb-4">Create New Post</h2>
            <select
              name="postType"
              value={newPostType}
              onChange={(e) => setNewPostType(e.target.value)}
              className="p-2 rounded-lg bg-[#1a1a4a] text-white border border-[#8a6eff] mb-2 block"
            >
              <option value="text">Text</option>
              <option value="image">Image</option>
              <option value="video">Video</option>
            </select>
            {newPostType !== "text" && (
              <input
                type="file"
                name="file"
                accept={newPostType === "image" ? "image/*" : "video/*"}
                onChange={handleNewPostFileChange}
                className="mb-2 block text-sm text-gray-900 bg-gray-50 rounded-lg border border-gray-300 cursor-pointer dark:text-gray-400 focus:outline-none dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400"
              />
            )}
            <textarea
              name="content"
              placeholder="Share your quantum experience..."
              value={newPostContent}
              onChange={handleNewPostChange}
              className="w-full p-2 rounded-lg bg-[#1a1a4a] text-white border border-[#8a6eff] mb-2"
            />
            <button
              onClick={handleSubmitNewPost}
              disabled={uploading}
              className="bg-[#8a6eff] hover:bg-[#7a5eff] text-white font-bold py-2 px-4 rounded-full disabled:opacity-50"
            >
              {uploading ? "Posting..." : "Post"}
            </button>
          </section>
        )}

        <section>
          <h2 className="text-2xl font-bold mb-4">Community Posts</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {posts.map((post) => (
              <div key={post._id} className="bg-[#2a1b6a] rounded-xl p-4">
                {previewForPost(post)}
                {user && (
                  <div>{post.type === "text" && <p>{post.content}</p>}</div>
                )}
              </div>
            ))}
          </div>
        </section>
      </main>

      <style jsx global>{`
        .glow {
          box-shadow: 0 0 15px 5px rgba(255, 255, 255, 0.7), 0 0 30px 15px rgba(138, 110, 255, 0.5), 0 0 45px 25px rgba(110, 255, 255, 0.3);
        }
      `}</style>
    </div>
  );
}

export default MainComponent;