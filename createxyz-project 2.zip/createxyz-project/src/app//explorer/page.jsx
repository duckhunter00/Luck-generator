"use client";
import React from "react";

function MainComponent() {
  const [email, setEmail] = useState("");
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [location, setLocation] = useState("");
  const [predictions, setPredictions] = useState([]);
  const [error, setError] = useState(null);

  const handleLocationChange = async (e) => {
    setLocation(e.target.value);
    try {
      const response = await fetch(
        `/integrations/google-place-autocomplete/autocomplete/json?input=${e.target.value}&radius=500`,
        { method: "GET" }
      );
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const data = await response.json();
      setPredictions(data.predictions);
    } catch (error) {
      console.error("Error fetching predictions:", error);
      setError("Could not fetch predictions. Please try again later.");
    }
  };

  const handlePredictionClick = (prediction) => {
    setLocation(prediction.description);
    setPredictions([]);
  };

  const handleEmailSubmit = async (e) => {
    e.preventDefault();
    if (email && email.includes("@") && location) {
      setIsSubmitted(true);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0a0a2a] to-[#1a1a4a] text-white font-poppins">
      <header className="py-6 px-4 md:px-12 flex justify-between items-center">
        <div className="flex items-center">
          <div className="w-[50px] h-[50px] rounded-full bg-[#5d3fd3] flex items-center justify-center">
            <i className="fas fa-atom text-2xl"></i>
          </div>
          <h1 className="ml-3 text-2xl md:text-3xl font-bold">
            QuantumNumerkat
          </h1>
        </div>
      </header>

      <main className="py-12 px-4 md:px-12 max-w-6xl mx-auto">
        <section className="mb-16 text-center">
          <h2 className="text-3xl font-bold mb-6">
            Quantum Number Set Generator
          </h2>
          <p className="text-lg max-w-3xl mx-auto mb-8 text-[#c4b5ff]">
            Enter your location and email to receive your personalized quantum
            number set.
          </p>
          <form
            onSubmit={handleEmailSubmit}
            className="flex flex-col md:flex-row gap-4 max-w-xl mx-auto"
          >
            <input
              type="text"
              name="location"
              placeholder="Enter your location"
              value={location}
              onChange={handleLocationChange}
              className="flex-grow py-3 px-4 rounded-full bg-[#1a1a4a] border border-[#8a6eff] text-white focus:outline-none focus:ring-2 focus:ring-[#8a6eff]"
              required
            />
            {predictions.length > 0 && (
              <div className="absolute bg-white text-black rounded-lg shadow-lg mt-2 w-full md:w-[calc(100%-32px)]">
                {predictions.map((prediction) => (
                  <div
                    key={prediction.place_id}
                    onClick={() => handlePredictionClick(prediction)}
                    className="p-2 hover:bg-gray-100 cursor-pointer"
                  >
                    {prediction.description}
                  </div>
                ))}
              </div>
            )}
            <input
              type="email"
              name="email"
              placeholder="Your email address"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="flex-grow py-3 px-4 rounded-full bg-[#1a1a4a] border border-[#8a6eff] text-white focus:outline-none focus:ring-2 focus:ring-[#8a6eff]"
              required
            />
            <button
              type="submit"
              className="bg-[#8a6eff] hover:bg-[#7a5eff] text-white font-bold py-3 px-6 rounded-full"
            >
              Get Your Set
            </button>
          </form>
          {isSubmitted && (
            <div className="bg-[#1a1a4a] p-4 rounded-xl border border-[#8a6eff] mt-4">
              <i className="fas fa-check-circle text-[#6effff] text-2xl mb-2"></i>
              <p className="text-lg">
                Thank you! Your quantum number set has been sent to {email}.
              </p>
            </div>
          )}
        </section>

        <section className="mb-16">
          <h2 className="text-3xl font-bold mb-6 border-l-4 border-[#8a6eff] pl-4">
            Recognizing Quantum Numbers
          </h2>
          <p className="text-lg mb-4">
            Quantum numbers influence everyday events, often subtly.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="text-xl font-semibold mb-2">Example 1: Timing</h3>
              <p className="text-base mb-2">
                Notice timings of events, like meeting a specific person or
                receiving unexpected news. These moments may correlate with your
                quantum number set.
              </p>
            </div>
            <div>
              <h3 className="text-xl font-semibold mb-2">
                Example 2: Numbers in Nature
              </h3>
              <p className="text-base mb-2">
                Observe numbers appearing in nature, like the number of birds in
                a flock or petals on a flower. These could be reflections of
                your quantum numbers.
              </p>
            </div>
          </div>
        </section>
      </main>

      <style jsx global>{`
        .glow {
          box-shadow: 0 0 15px 5px rgba(255, 255, 255, 0.7), 0 0 30px 15px rgba(138, 110, 255, 0.5), 0 0 45px 25px rgba(110, 255, 255, 0.3);
        }
      `}</style>
    </div>
  );
}

export default MainComponent;