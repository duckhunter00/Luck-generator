"use client";
import React from "react";

function MainComponent() {
  const [email, setEmail] = useState("");
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [modalContent, setModalContent] = useState("");

  const handleEmailSubmit = (e) => {
    e.preventDefault();
    if (email && email.includes("@")) {
      setIsSubmitted(true);
    }
  };

  const handlePremiumClick = (content) => {
    setModalContent(content);
    setShowModal(true);
  };

  const quantumNumbers = [
    {
      number: 1,
      type: "Attractor",
      description:
        "Focus, manifestation, new beginnings. Use for setting intentions and initiating projects.",
      example: "Visualize your goals while focusing on this number.",
    },
    {
      number: 2,
      type: "Void",
      description:
        "Release, letting go, creating space. Use for clearing negativity and making room for new opportunities.",
      example: "Meditate on this number while releasing anxieties.",
    },
    {
      number: 3,
      type: "Power",
      description:
        "Growth, expansion, creativity. Use for boosting projects and amplifying positive energy.",
      example: "Use this number during creative brainstorming sessions.",
    },
    {
      number: 4,
      type: "Attractor",
      description:
        "Stability, grounding, building foundations. Use for strengthening relationships and creating secure structures.",
      example: "Focus on this number during family time.",
    },
    {
      number: 5,
      type: "Void",
      description:
        "Transformation, change, adaptability. Use for navigating transitions and embracing new perspectives.",
      example: "Reflect on this number during periods of change.",
    },
    {
      number: 6,
      type: "Power",
      description:
        "Harmony, balance, connection. Use for improving relationships and finding inner peace.",
      example: "Visualize this number while practicing forgiveness.",
    },
    {
      number: 7,
      type: "Attractor",
      description:
        "Intuition, inner wisdom, spiritual growth. Use for deepening your connection to your higher self.",
      example: "Meditate on this number during spiritual practices.",
    },
    {
      number: 8,
      type: "Void",
      description:
        "Abundance, prosperity, manifestation. Use for attracting wealth and materializing desires.",
      example: "Visualize your financial goals while focusing on this number.",
    },
    {
      number: 9,
      type: "Power",
      description:
        "Completion, integration, wisdom. Use for celebrating achievements and integrating lessons learned.",
      example: "Reflect on this number at the end of projects or cycles.",
    },
  ];

  const howToUseInstructions = [
    {
      type: "Attractor",
      instructions: [
        "Identify a specific goal or desire.",
        "Focus your attention on your Attractor number.",
        "Visualize your desired outcome while meditating on the number.",
        "Repeat this process daily to amplify your manifestation power.",
      ],
    },
    {
      type: "Void",
      instructions: [
        "Identify a negative emotion or limiting belief you want to release.",
        "Focus on your Void number.",
        "Visualize the negativity dissolving as you meditate on the number.",
        "Practice this regularly to create space for positive change.",
      ],
    },
    {
      type: "Power",
      instructions: [
        "Identify an area of your life where you want to experience growth or expansion.",
        "Focus your intention on your Power number.",
        "Visualize the positive energy amplifying as you meditate on the number.",
        "Use this technique to boost your projects and enhance your creative power.",
      ],
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0a0a2a] to-[#1a1a4a] text-white font-poppins">
      <header className="py-6 px-4 md:px-12 flex justify-between items-center">
        <div className="flex items-center">
          <div className="w-[50px] h-[50px] rounded-full bg-[#5d3fd3] flex items-center justify-center">
            <i className="fas fa-atom text-2xl"></i>
          </div>
          <h1 className="ml-3 text-2xl md:text-3xl font-bold">
            Quantum Knowledge
          </h1>
        </div>
        <nav>
          <ul className="flex space-x-6">
            <li>
              <a href="/" className="hover:text-[#8a6eff]">
                Home
              </a>
            </li>
            <li>
              <a href="/explorer" className="hover:text-[#8a6eff]">
                Explorer
              </a>
            </li>
          </ul>
        </nav>
      </header>

      <section className="py-12 px-4 md:px-12 text-center">
        <h1 className="text-4xl md:text-6xl font-bold mb-6">
          Unlock Your Quantum Potential
        </h1>
        <p className="text-xl md:text-2xl max-w-3xl mx-auto text-[#c4b5ff]">
          Discover how quantum principles can transform your life through
          personalized quantum number sets
        </p>
        <div className="mt-12 relative w-full max-w-4xl mx-auto h-[300px] md:h-[400px] rounded-xl overflow-hidden">
          <div className="absolute inset-0 bg-[#2a1b6a] opacity-60 rounded-xl"></div>
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-[200px] h-[200px] md:w-[300px] md:h-[300px] relative">
              <div className="absolute inset-0 rounded-full border-4 border-[#8a6eff] animate-[spin_20s_linear_infinite]"></div>
              <div
                className="absolute inset-0 rounded-full border-4 border-[#ff6ebd] animate-[spin_15s_linear_infinite_reverse]"
                style={{ margin: "20px" }}
              ></div>
              <div
                className="absolute inset-0 rounded-full border-4 border-[#6effff] animate-[spin_10s_linear_infinite]"
                style={{ margin: "40px" }}
              ></div>
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-[50px] h-[50px] md:w-[80px] md:h-[80px] bg-[#ffffff] rounded-full glow"></div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <main className="py-12 px-4 md:px-12 max-w-6xl mx-auto">
        <section className="mb-16">
          <h2 className="text-3xl font-bold mb-6 border-l-4 border-[#6effff] pl-4">
            Using Your Quantum Number Set
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {quantumNumbers.map((num) => (
              <div key={num.number} className="bg-[#2a1b6a] rounded-xl p-6">
                <h3 className="text-xl font-bold mb-2 text-center">
                  {num.number} - {num.type}
                </h3>
                <p className="text-lg mb-4">{num.description}</p>
                <p className="italic text-[#c4b5ff]">Example: {num.example}</p>
              </div>
            ))}
          </div>
        </section>

        <section className="mb-16">
          <h2 className="text-3xl font-bold mb-6 border-l-4 border-[#8a6eff] pl-4">
            How to Use Your Quantum Numbers
          </h2>
          {howToUseInstructions.map((instruction) => (
            <div key={instruction.type} className="mb-8">
              <h3 className="text-2xl font-semibold mb-4">
                {instruction.type} Numbers
              </h3>
              <ol className="list-decimal pl-6">
                {instruction.instructions.map((step, index) => (
                  <li key={index} className="text-lg mb-2">
                    {step}
                  </li>
                ))}
              </ol>
            </div>
          ))}
        </section>

        <section className="mb-16 bg-[#2a1b6a] rounded-xl p-8">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-4">
              Join Our 7-Day Quantum Learning Series
            </h2>
            <p className="text-lg mb-6">
              Receive daily lessons on harnessing your quantum potential,
              delivered directly to your inbox. Discover how to align with your
              quantum numbers and transform your reality.
            </p>
            {!isSubmitted ? (
              <form
                onSubmit={handleEmailSubmit}
                className="flex flex-col md:flex-row gap-4 max-w-xl mx-auto"
              >
                <input
                  type="email"
                  name="email"
                  placeholder="Your email address"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="flex-grow py-3 px-4 rounded-full bg-[#1a1a4a] border border-[#8a6eff] text-white focus:outline-none focus:ring-2 focus:ring-[#8a6eff]"
                  required
                />
                <button
                  type="submit"
                  className="bg-[#8a6eff] hover:bg-[#7a5eff] text-white font-bold py-3 px-6 rounded-full"
                >
                  Start Your Journey
                </button>
              </form>
            ) : (
              <div className="bg-[#1a1a4a] p-4 rounded-xl border border-[#8a6eff]">
                <i className="fas fa-check-circle text-[#6effff] text-2xl mb-2"></i>
                <p className="text-lg">
                  Thank you! Your quantum journey begins soon. Check your inbox
                  for your first lesson.
                </p>
              </div>
            )}
          </div>
        </section>

        <section className="mb-16">
          <h2 className="text-3xl font-bold mb-8 text-center">
            Success Stories
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-[#2a1b6a] rounded-xl p-6">
              <div className="flex items-center mb-4">
                <div className="w-[60px] h-[60px] rounded-full bg-[#1a1a4a] flex items-center justify-center">
                  <i className="fas fa-user text-[#8a6eff] text-2xl"></i>
                </div>
                <div className="ml-4">
                  <h3 className="font-bold">Sarah K.</h3>
                  <div className="flex text-[#ffb36e]">
                    <i className="fas fa-star"></i>
                    <i className="fas fa-star"></i>
                    <i className="fas fa-star"></i>
                    <i className="fas fa-star"></i>
                    <i className="fas fa-star"></i>
                  </div>
                </div>
              </div>
              <p className="italic">
                "After discovering my quantum number set, I've experienced
                remarkable synchronicities in my career. Opportunities align
                perfectly with my intentions, and I feel a deeper connection to
                the universe's flow."
              </p>
            </div>
            <div className="bg-[#2a1b6a] rounded-xl p-6">
              <div className="flex items-center mb-4">
                <div className="w-[60px] h-[60px] rounded-full bg-[#1a1a4a] flex items-center justify-center">
                  <i className="fas fa-user text-[#ff6ebd] text-2xl"></i>
                </div>
                <div className="ml-4">
                  <h3 className="font-bold">Michael T.</h3>
                  <div className="flex text-[#ffb36e]">
                    <i className="fas fa-star"></i>
                    <i className="fas fa-star"></i>
                    <i className="fas fa-star"></i>
                    <i className="fas fa-star"></i>
                    <i className="fas fa-star-half-alt"></i>
                  </div>
                </div>
              </div>
              <p className="italic">
                "The personalized quantum training transformed my approach to
                decision-making. By aligning with my quantum numbers, I've
                eliminated uncertainty and found clarity in both personal and
                business choices."
              </p>
            </div>
            <div className="bg-[#2a1b6a] rounded-xl p-6">
              <div className="flex items-center mb-4">
                <div className="w-[60px] h-[60px] rounded-full bg-[#1a1a4a] flex items-center justify-center">
                  <i className="fas fa-user text-[#6effff] text-2xl"></i>
                </div>
                <div className="ml-4">
                  <h3 className="font-bold">Jennifer R.</h3>
                  <div className="flex text-[#ffb36e]">
                    <i className="fas fa-star"></i>
                    <i className="fas fa-star"></i>
                    <i className="fas fa-star"></i>
                    <i className="fas fa-star"></i>
                    <i className="fas fa-star"></i>
                  </div>
                </div>
              </div>
              <p className="italic">
                "The 7-day email course was just the beginning. Understanding
                how emotional energy affects quantum states has helped me
                manifest positive relationships and opportunities I never
                thought possible."
              </p>
            </div>
          </div>
        </section>
      </main>

      <footer className="py-8 px-4 md:px-12 bg-[#0a0a2a] text-center">
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-center mb-8">
            <div className="flex items-center mb-4 md:mb-0">
              <div className="w-[40px] h-[40px] rounded-full bg-[#5d3fd3] flex items-center justify-center">
                <i className="fas fa-atom text-xl"></i>
              </div>
              <h2 className="ml-3 text-xl font-bold">Quantum Knowledge</h2>
            </div>
            <nav>
              <ul className="flex space-x-6">
                <li>
                  <a href="/" className="hover:text-[#8a6eff]">
                    Home
                  </a>
                </li>
                <li>
                  <a href="/explorer" className="hover:text-[#8a6eff]">
                    Explorer
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-[#8a6eff]">
                    Privacy Policy
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-[#8a6eff]">
                    Terms of Service
                  </a>
                </li>
              </ul>
            </nav>
          </div>
          <p className="text-[#8a8aaa]">
            © 2025 Quantum Knowledge. All rights reserved.
          </p>
        </div>
      </footer>

      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-50 p-4">
          <div className="bg-[#1a1a4a] rounded-xl p-6 max-w-md w-full">
            <h3 className="text-2xl font-bold mb-4">Unlock Premium Content</h3>
            <p className="mb-6">
              {modalContent === "advanced"
                ? "Gain access to Advanced Quantum Techniques for $49.99"
                : "Get your Personalized Quantum Training for $99.99"}
            </p>
            <div className="flex flex-col space-y-4">
              <button className="bg-[#8a6eff] hover:bg-[#7a5eff] text-white font-bold py-2 px-6 rounded-full">
                Purchase Now
              </button>
              <button
                onClick={() => setShowModal(false)}
                className="bg-transparent border border-[#8a6eff] text-white font-bold py-2 px-6 rounded-full hover:bg-[#2a1b6a]"
              >
                Maybe Later
              </button>
            </div>
          </div>
        </div>
      )}

      <style jsx global>{`
        @keyframes spin {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
        @keyframes pulse {
          0% { transform: scale(0.95); opacity: 0.7; }
          50% { transform: scale(1.05); opacity: 1; }
          100% { transform: scale(0.95); opacity: 0.7; }
        }
        .glow {
          box-shadow: 0 0 15px 5px rgba(255, 255, 255, 0.7), 0 0 30px 15px rgba(138, 110, 255, 0.5), 0 0 45px 25px rgba(110, 255, 255, 0.3);
        }
      `}</style>
    </div>
  );
}

export default MainComponent;