"use client";
import React from "react";
import StylizedButton from "../../components/stylized-button";

function MainComponent() {
  const { signOut } = useAuth();
  const { data: user } = useUser();
  const [isDeleting, setIsDeleting] = useState(false);
  const [deleteError, setDeleteError] = useState(null);

  const handleDeleteAccount = async () => {
    if (
      confirm(
        "Are you sure you want to delete your account? This action cannot be undone."
      )
    ) {
      try {
        setIsDeleting(true);
        const response = await fetch("/api/delete-user-account", {
          method: "POST",
        });
        if (!response.ok) {
          throw new Error(
            `When deleting account, the response was [${response.status}] ${response.statusText}`
          );
        }
        await signOut({ callbackUrl: "/", redirect: true });
      } catch (error) {
        console.error("Error deleting account:", error);
        setDeleteError("Failed to delete account. Please try again later.");
      } finally {
        setIsDeleting(false);
      }
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-[#EDECE2] flex items-center justify-center font-montserrat">
        <p className="text-4xl font-semibold tracking-tighter text-[#F5663B]">
          You need to be signed in to access this page.
        </p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#EDECE2] p-4 md:p-12 font-montserrat">
      <h1 className="text-6xl font-semibold tracking-tighter text-[#F5663B] mb-8">
        Account Settings
      </h1>

      {deleteError && (
        <div
          className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4"
          role="alert"
        >
          <strong className="font-bold">Error:</strong>
          <span className="block sm:inline"> {deleteError}</span>
        </div>
      )}

      <StylizedButton onClick={handleDeleteAccount} disabled={isDeleting}>
        {isDeleting ? "Deleting Account..." : "Delete Account"}
      </StylizedButton>
      <style jsx global>{`
        @keyframes pulse {
          0% { transform: scale(0.95); opacity: 0.7; }
          50% { transform: scale(1.05); opacity: 1; }
          100% { transform: scale(0.95); opacity: 0.7; }
        }
      `}</style>
    </div>
  );
}

export default MainComponent;