async function handler({ req }) {
  const session = getSession(req);

  if (!session) {
    return { status: 401, message: "Unauthorized" };
  }

  try {
    await sql.transaction(async (tx) => {
      await tx`DELETE FROM auth_accounts WHERE "userId" = ${session.user.id}`;
      await tx`DELETE FROM auth_sessions WHERE "userId" = ${session.user.id}`;
      await tx`DELETE FROM auth_users WHERE id = ${session.user.id}`;
    });

    return { status: 200, message: "Account deleted successfully" };
  } catch (error) {
    console.error("Error deleting user:", error);
    return { status: 500, message: "Failed to delete account" };
  }
}